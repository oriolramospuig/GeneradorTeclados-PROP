# Directori test

> Path absolut: /FONTS/src/test

## Descripció del directori

Aquest directori conté els tests de cada una de les classes programades.

## Elements del directori

- **Directori functions:**
  Conté els tests de totes les classes que realitzen alguna funcionalitat.
- **Directori types:**
  Conté els tests de totes les classes que representen algun tipus de dades nou.
- **MasterTestSuite:**
  Conté les instàncies *.class* de TestSuiteFunctions i TestSuiteTipus, per fer més fàcil al *Makefile* compilar els
  tests.