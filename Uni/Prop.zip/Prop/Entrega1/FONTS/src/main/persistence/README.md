# Directori persistance

> Path absolut: /FONTS/src/main/domain/persistance

## Descripció del directori
Aquest directori conté els codis de la capa de persistència

## Elements del directori
Aquest directori resta buit per la primera entrega