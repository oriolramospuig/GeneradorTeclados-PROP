# Directori domain

> Path absolut: /FONTS/src/main/domain

## Descripció del directori
Aquest directori conté tots els codis de la capa de domini classificats per classes i controladors.

## Elements del directori

- **Directori classes:**
  Conté les classes de la capa de domini.
- **Directori controllers:**
  Conté els controladors de la capa de domini.