package main.domain.classes;

public enum Algoritmo {
    QAP,
    Alg2
}
