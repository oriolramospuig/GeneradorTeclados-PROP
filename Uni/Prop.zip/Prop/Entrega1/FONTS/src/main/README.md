# Directori main

> Path absolut: /FONTS/src/main

## Descripció del directori
Aquest directori conté el codi del sistema classificat per les tres capes: domini, persistència i presentació

## Elements del directori

- **Directori domain:**
  Conté els codis de la capa de domini.
- **Directori persistence:**
  Conté els codis de la capa de persistència.
- **Directori presentation:**
  Conté els codis de la capa de presentació.