# Directorio DOCS

> Path absoluto: /DOCS

## Descripción del directorio

Este directorio contiene la documentación de la segunda entrega

## Elementos del directori
- **Documentación 2a entrega.pdf**

- **UML - Capa de Dominio.svg**

- **UML - Capa de Persistencia.svg**

- **UML - Capa de Presentación.svg**